/** Automatically generated file. DO NOT MODIFY */
package com.example.lab1_101047;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}