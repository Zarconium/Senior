package com.example.lab4_101047;

import android.os.Bundle;
import android.app.*;
import android.widget.*;

public class MovieListActivity extends ListActivity {

	//private CustomAdapter adapter;
	//private ArrayList<Movie> movies;
	private String[] movies;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		//setContentView(R.layout.activity_list);
		
		movies = getResources().getStringArray(R.array.movies_list);
		setListAdapter(new ArrayAdapter<String>(this, R.layout.list_item, movies));
		
		ListView lv = getListView();
		lv.setTextFilterEnabled(true);
	}
	
	/*private class CustomAdapter extends BaseAdapter
	{
		private ArrayList<Movie> list;
		
		public CustomAdapter(ArrayList<Movie> movies)
		{
			this.list = movies;
		}
		
		@Override
		public int getCount()
		{
			return list.size();
		}

		@Override
		public Object getItem(int index)
		{
			return list.get(index);
		}

		@Override
		public long getItemId(int position)
		{
			return position;
		}

		@Override
		public View getView(int position, View convertView, ViewGroup parent)
		{
			LayoutInflater inflater = getLayoutInflater();
			View view;
			
			if(convertView == null)
			{
				view = inflater.inflate(R.layout.row, null);
			}
			else
			{
				view = convertView;
			}
			
			//TextView rank = (TextView) view.findViewById(R.id.textViewRank);
			TextView title = (TextView) view.findViewById(R.id.textViewTitle);
			//TextView gross = (TextView) view.findViewById(R.id.textViewGross);
			//TextView year = (TextView) view.findViewById(R.id.textViewYear);
			
			Movie movie = list.get(position);
			
			//rank.setText(movie.getRank());
			title.setText(movie.getTitle());
			//gross.setText(movie.getGross());
			//year.setText(movie.getYear());
			
			return view;
		}
		
	}*/
}