/** Automatically generated file. DO NOT MODIFY */
package com.example.customizations;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}