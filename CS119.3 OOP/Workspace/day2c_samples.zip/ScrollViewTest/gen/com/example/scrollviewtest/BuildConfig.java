/** Automatically generated file. DO NOT MODIFY */
package com.example.scrollviewtest;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}