require 'test_helper'

class StudentSubjectTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
