# Be sure to restart your server when you modify this file.

# Your secret key is used for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!

# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
# You can use `rake secret` to generate a secure secret key.

# Make sure your secret_key_base is kept private
# if you're sharing your code publicly.
Studentmanagementsystem::Application.config.secret_key_base = '604ed3fb5b32c8aa2f72ed85cfc11b57fdeecbc496bd38bd72b64cbcaf5b9b06ec4a00ffc4ac7ad183ca0604f1202baec8410b0bcbb896d105347d331cb67166'
