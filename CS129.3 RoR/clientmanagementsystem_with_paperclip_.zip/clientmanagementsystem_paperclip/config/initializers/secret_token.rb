# Be sure to restart your server when you modify this file.

# Your secret key is used for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!

# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
# You can use `rake secret` to generate a secure secret key.

# Make sure your secret_key_base is kept private
# if you're sharing your code publicly.
Clientmanagementsystem::Application.config.secret_key_base = '2b4855a2c73b75c9f2f7699b6b392605ed01aa420419cc5738335a9d0854b7ab143c09f8d8017f09c7df8f324513e7eac47ca5c601f5c72c2f9b1bc01df30d97'
