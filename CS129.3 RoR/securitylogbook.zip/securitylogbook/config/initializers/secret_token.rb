# Be sure to restart your server when you modify this file.

# Your secret key is used for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!

# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
# You can use `rake secret` to generate a secure secret key.

# Make sure your secret_key_base is kept private
# if you're sharing your code publicly.
Securitylogbook::Application.config.secret_key_base = '441d1026bd1cc88431584201574fdaf7f13f56b3197774b21bb08c8cc21bd3555f0010f403c7786f28c878f904655d6949bdfa6dabb13bf1a659cf40e56d33f7'
