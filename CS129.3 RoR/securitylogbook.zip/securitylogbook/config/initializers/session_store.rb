# Be sure to restart your server when you modify this file.

Securitylogbook::Application.config.session_store :cookie_store, key: '_securitylogbook_session'
