module OfficeHelper
end
