module LogRecordsHelper
end
