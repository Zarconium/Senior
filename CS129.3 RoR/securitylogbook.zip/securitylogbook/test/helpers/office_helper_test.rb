require 'test_helper'

class OfficeHelperTest < ActionView::TestCase
end
