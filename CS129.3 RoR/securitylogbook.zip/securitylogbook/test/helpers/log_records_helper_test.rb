require 'test_helper'

class LogRecordsHelperTest < ActionView::TestCase
end
