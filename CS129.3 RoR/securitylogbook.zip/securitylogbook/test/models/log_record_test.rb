require 'test_helper'

class LogRecordTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
