# Be sure to restart your server when you modify this file.

# Your secret key is used for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!

# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
# You can use `rake secret` to generate a secure secret key.

# Make sure your secret_key_base is kept private
# if you're sharing your code publicly.
Reportcard::Application.config.secret_key_base = 'a402ebe990176a68c0be5687c0d78dad586456a8294b5997820ccbfee9fc6a1354c691bf2defbc5411bd0f63bc1f15f781057e3a927d09279efe908bc27a87c9'
