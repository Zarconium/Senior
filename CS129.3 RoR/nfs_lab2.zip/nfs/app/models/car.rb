class Car < ActiveRecord::Base
end
