# Be sure to restart your server when you modify this file.

# Your secret key is used for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!

# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
# You can use `rake secret` to generate a secure secret key.

# Make sure your secret_key_base is kept private
# if you're sharing your code publicly.
Albumcatalog::Application.config.secret_key_base = '90e3d1cace349ab56fc565466b3d7c032cafbe2c0688c689c7d225db5f86387cc467b477cce826438796deb56bc8d8d3c6caa11141a244330d1ec08c78ec2369'
