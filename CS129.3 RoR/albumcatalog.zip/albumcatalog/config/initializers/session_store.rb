# Be sure to restart your server when you modify this file.

Albumcatalog::Application.config.session_store :cookie_store, key: '_albumcatalog_session'
