class Person
	attr_accessor :first_name, :last_name, :gender
	
	def initialize(first_name, last_name, gender)
		@first_name = first_name
		@last_name = last_name
		@gender = gender
	end
end
