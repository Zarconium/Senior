require 'test_helper'

class UserEntryTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
