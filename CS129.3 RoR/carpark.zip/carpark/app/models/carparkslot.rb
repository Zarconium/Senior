class Carparkslot < ActiveRecord::Base
end
